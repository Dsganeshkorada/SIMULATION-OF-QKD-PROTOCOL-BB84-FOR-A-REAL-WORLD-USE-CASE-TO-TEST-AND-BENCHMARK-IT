from flask import Flask, render_template, request, redirect, url_for, session, flash
import numpy as np
from qutip import basis, Qobj
import PyPDF2
import random
import io

# Initialize Flask app
app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with a secure secret key

# Constants
NUM_QUBITS = 100
QBER_THRESHOLD = 11
NOISE_PROBABILITY = 0.05  # Probability of noise affecting a qubit
EAVESDROPPING_PROBABILITY = 0.1  # Probability of Eve intercepting a qubit

# In-memory storage for uploaded and received files
uploaded_files = {}
received_files = {}

# Define the Hadamard gate manually
def hadamard_transform():
    return Qobj([[1, 1], [1, -1]]) / np.sqrt(2)

def generate_random_bits(num_qubits):
    return np.random.randint(0, 2, num_qubits)

def generate_random_bases(num_qubits):
    return np.random.randint(0, 2, num_qubits)

# Step 2: Prepare qubits with added noise
def prepare_qubits(bits, bases):
    qubits = []
    H = hadamard_transform()
    for i in range(len(bits)):
        qubit = basis(2, bits[i]) if bases[i] == 0 else H * basis(2, bits[i])
        
        # Introduce noise
        if random.random() < NOISE_PROBABILITY:
            qubit = H * qubit  # Apply a flip due to noise
        qubits.append(qubit)
    return qubits

# Step 3: Eavesdrop on qubits
def eavesdrop(qubits, alice_bases):
    eve_bases = generate_random_bases(len(qubits))
    intercepted_qubits = []
    for i in range(len(qubits)):
        if random.random() < EAVESDROPPING_PROBABILITY:  # Eve intercepts
            if eve_bases[i] == 0:
                prob_0 = np.abs((basis(2, 0).dag() * qubits[i]))**2
                prob_1 = np.abs((basis(2, 1).dag() * qubits[i]))**2
            else:
                ket_plus = (basis(2, 0) + basis(2, 1)).unit()
                ket_minus = (basis(2, 0) - basis(2, 1)).unit()
                prob_0 = np.abs((ket_plus.dag() * qubits[i]))**2
                prob_1 = np.abs((ket_minus.dag() * qubits[i]))**2
            
            prob_0, prob_1 = prob_0.real, prob_1.real
            prob_0 /= prob_0 + prob_1 if (prob_0 + prob_1) != 0 else 1
            intercepted_bit = np.random.choice([0, 1], p=[prob_0, prob_1])
            intercepted_qubits.append(basis(2, intercepted_bit) if eve_bases[i] == 0 else hadamard_transform() * basis(2, intercepted_bit))
        else:
            intercepted_qubits.append(qubits[i])
    return intercepted_qubits

# Step 4: Measure qubits
def measure_qubits(qubits, bases):
    measured_bits = []
    for i in range(len(qubits)):
        if bases[i] == 0:
            prob_0 = np.abs((basis(2, 0).dag() * qubits[i]))**2
            prob_1 = np.abs((basis(2, 1).dag() * qubits[i]))**2
        else:
            ket_plus = (basis(2, 0) + basis(2, 1)).unit()
            ket_minus = (basis(2, 0) - basis(2, 1)).unit()
            prob_0 = np.abs((ket_plus.dag() * qubits[i]))**2
            prob_1 = np.abs((ket_minus.dag() * qubits[i]))**2
        
        prob_0, prob_1 = prob_0.real, prob_1.real
        prob_0 /= prob_0 + prob_1 if (prob_0 + prob_1) != 0 else 1
        measured_bit = np.random.choice([0, 1], p=[prob_0, prob_1])
        measured_bits.append(measured_bit)
    return measured_bits

def compare_bases(alice_bases, bob_bases):
    return [i for i in range(len(alice_bases)) if alice_bases[i] == bob_bases[i]]

def sift_key(bits, indices):
    return [bits[i] for i in indices]

def calculate_qber(alice_key, bob_key):
    errors = sum(1 for a, b in zip(alice_key, bob_key) if a != b)
    return (errors / len(alice_key)) * 100 if len(alice_key) > 0 else 100

# Error Correction and Privacy Amplification (Simulated)
def error_correction(alice_key, bob_key):
    return alice_key, bob_key

def privacy_amplification(key):
    return key[:len(key) // 2]

# Encrypt and Decrypt Messages
def encrypt_message(message, key):
    message_bits = ''.join(format(byte, '08b') for byte in message.encode('utf-8'))
    key_bits = ''.join(str(bit) for bit in key)
    extended_key = (key_bits * ((len(message_bits) // len(key_bits)) + 1))[:len(message_bits)]
    return ''.join(str(int(m_bit) ^ int(k_bit)) for m_bit, k_bit in zip(message_bits, extended_key))

def decrypt_message(encrypted_bits, key):
    key_bits = ''.join(str(bit) for bit in key)
    extended_key = (key_bits * ((len(encrypted_bits) // len(key_bits)) + 1))[:len(encrypted_bits)]
    decrypted_bits = ''.join(str(int(e_bit) ^ int(k_bit)) for e_bit, k_bit in zip(encrypted_bits, extended_key))
    return ''.join(chr(int(decrypted_bits[i:i+8], 2)) for i in range(0, len(decrypted_bits), 8))

def extract_text_from_pdf(file_stream):
    reader = PyPDF2.PdfReader(file_stream)
    return ''.join(page.extract_text() or "" for page in reader.pages)

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = request.form['username']
        if user.lower() in ['hospital 1', 'hospital 2']:
            session['username'] = user.lower()
            return redirect(url_for('dashboard'))
        flash('Invalid username. Please log in as Hospital 1 or Hospital 2.')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))
    user = session['username']
    if user == 'hospital 1':
        if request.method == 'POST':
            file = request.files['file']
            if file and file.filename.endswith('.pdf'):
                file_content = extract_text_from_pdf(io.BytesIO(file.read()))
                uploaded_files['hospital 1'] = file_content
                flash('File uploaded successfully.')
                return redirect(url_for('transfer'))
            flash('Invalid file format. Please upload a PDF file.')
        return render_template('hospital1_dashboard.html')
    elif user == 'hospital 2':
        file_content = decrypt_message(*received_files['hospital 2']) if 'hospital 2' in received_files else None
        return render_template('hospital2_dashboard.html', file_content=file_content)

@app.route('/transfer')
def transfer():
    if 'username' not in session or session['username'] != 'hospital 1':
        flash('Access denied.')
        return redirect(url_for('login'))
    if 'hospital 1' not in uploaded_files:
        flash('No file to transfer.')
        return redirect(url_for('dashboard'))
    
    alice_bits = generate_random_bits(NUM_QUBITS)
    alice_bases = generate_random_bases(NUM_QUBITS)
    qubits = prepare_qubits(alice_bits, alice_bases)
    intercepted_qubits = eavesdrop(qubits, alice_bases)
    bob_bases = generate_random_bases(NUM_QUBITS)
    bob_bits = measure_qubits(intercepted_qubits, bob_bases)
    
    matching_indices = compare_bases(alice_bases, bob_bases)
    alice_key = sift_key(alice_bits, matching_indices)
    bob_key = sift_key(bob_bits, matching_indices)

    if len(alice_key) < 10:
        flash('Key exchange failed due to insufficient key length.')
        return redirect(url_for('dashboard'))
    
    qber = calculate_qber(alice_key, bob_key)
    if qber < QBER_THRESHOLD:
        alice_key_corrected, bob_key_corrected = error_correction(alice_key, bob_key)
        alice_final_key = privacy_amplification(alice_key_corrected)
        bob_final_key = privacy_amplification(bob_key_corrected)

        file_content = uploaded_files['hospital 1']
        encrypted_content = encrypt_message(file_content, alice_final_key)
        received_files['hospital 2'] = (encrypted_content, bob_final_key)
        
        flash('File transferred securely to Hospital 2.')
        flash(f'QBER : {qber:.2f}%')
    else:
        flash(f'Key exchange failed. QBER is {qber:.2f}%.')
    return redirect(url_for('dashboard'))

# Run the app
if __name__ == '__main__':
    app.run(debug=True)
